package com.infinite.assess7;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

/**
 * @author nithinko
 *
 */
@SpringBootApplication
@EnableAutoConfiguration(exclude = { HibernateJpaAutoConfiguration.class })
public class TestClass {
	private static final Logger logger = Logger.getLogger(TestClass.class);

		public static void main(String[] args) {
			PropertyConfigurator.configure("Log4j.properties");
			SpringApplication.run(TestClass.class, args);
		}
}