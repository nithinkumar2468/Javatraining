package com.infinite.assess7.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infinite.assess7.model.Municipal;
import com.infinite.assess7.repository.MunicipalDAOImpl;

@Service
public class MunicipalServiceImpl implements IMunicipalService {
	private static final Logger logger = Logger.getLogger(MunicipalServiceImpl.class);

	@Autowired
	MunicipalDAOImpl MunicipalDAOImpl;

	@Override
	@Transactional
	public List<Municipal> getAllComplains() {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("Log4j.properties");
		logger.info("It is working");
		return MunicipalDAOImpl.getAllComplains();
	}

	@Override
	@Transactional
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("Log4j.properties");
		logger.info("Get Municipal is working");
		return MunicipalDAOImpl.getMunicipal(id);
	}

	@Override
	@Transactional
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.addMunicipal(municipal);
	}

	@Override
	@Transactional
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.updateMunicipal(municipal);
	}

	@Override
	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.deleteMunicipal(id);
	}

}