package com.infinite.assess7.repository;

import java.util.List;

import com.infinite.assess7.model.Municipal;

public interface IMunicipalDAO {
	public List<Municipal> getAllComplains();// to display list of all Complains

	public Municipal getMunicipal(int id);// to get the details by id

	public Municipal addMunicipal(Municipal municipal);// inserting details

	public void updateMunicipal(Municipal municipal);// updating the details

	public void deleteMunicipal(int id);// deleting

}