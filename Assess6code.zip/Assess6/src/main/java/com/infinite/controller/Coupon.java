package com.infinite.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.daoimpl.ProductImpl;
import com.infinite.pojo.Product;

/**
 * @author nithinko
 *
 */
@Controller
public class Coupon {
	private ApplicationContext con;  //initializing applicationcontext
	@RequestMapping(value="/insert",method=RequestMethod.POST)  //request mapper to find child controller
	public String insert(@ModelAttribute("bean") Product e,Model m){  //model and getting attribute
		con=new ClassPathXmlApplicationContext("ApplicationContext.xml");  //creating object for applicationcontext
		ProductImpl obj=con.getBean("dao",ProductImpl.class); //getting productimpl using bean id
		//obj.updateData(e);	//updating
		String ProductName=e.getProductName();
		int Price=e.getPrice();
		int Quantity=e.getQuantity();
		int SubTotal=e.getSubTotal();
		//Session sessionobj = sessionFactory;
		//m.addAttribute("msg",ProductName); 
		//System.out.println("i");
		return "inserted";	
	}

	//for applying coupon
	@RequestMapping(value = "/coupon", method = RequestMethod.POST)
	public String coupon() {
		return "apply";
	}

}
